package observer;

public interface Locomocao {

	public void locomover();
	
}
