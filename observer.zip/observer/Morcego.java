package observer;

public class Morcego extends Mamifero implements Observer {

	@Override
	public float calcularCusto() {
		// TODO Auto-generated method stub
		return getCotacao() * 4;
	}
	
	public void atualizar(float cotacao) {
		// TODO Auto-generated method stub
		setCotacao(cotacao);
	}
	

}
