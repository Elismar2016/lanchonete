package observer;

public abstract class Ave extends Animal{


}
