package observer;

public class Pipila implements EmitirSom{

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		System.out.println("Pipiplando ...");
	}

}
