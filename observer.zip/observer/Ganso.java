package observer;

public class Ganso extends Ave implements Observer{

	@Override
	public float calcularCusto() {
		// TODO Auto-generated method stub
		return getCotacao() * 2;
	}

	public void atualizar(float cotacao) {
		// TODO Auto-generated method stub
		setCotacao(cotacao);
	}
	
}
