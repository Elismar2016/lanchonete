package observer;

public class Corvo extends Ave implements Observer{
 
	@Override
	public float calcularCusto() {
		// TODO Auto-generated method stub
		
		return getCotacao() * 3;
	}

	public void atualizar(float cotacao) {
		// TODO Auto-generated method stub
		setCotacao(cotacao);
	}	


}
