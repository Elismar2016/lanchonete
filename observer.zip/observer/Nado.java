package observer;

public class Nado implements Locomocao{

	@Override
	public void locomover() {
		// TODO Auto-generated method stub
		System.out.println("nadando ...");
	}

}
