package observer;

import java.util.ArrayList;
import java.util.List;

public class Exec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Pato pato1 = new Pato();
		pato1.setNome("Donald");
		pato1.setEmitirSom(new Grasno());
		pato1.getEmitirSom().emitirSom();
		pato1.setLocomover(new Nado());
		pato1.getLocomover().locomover();
		
		Ganso ganso1 = new Ganso();
		ganso1.setNome("Paulo Henrique");
		ganso1.setEmitirSom(new Grasno());
		ganso1.getEmitirSom().emitirSom();
		
		Morcego morcego1 = new Morcego();
		morcego1.setNome("Batman");
		morcego1.setEmitirSom(new Farfilha());
		morcego1.getEmitirSom().emitirSom();
		
		
		List<Animal> lista = new ArrayList<Animal>();
		lista.add(pato1);
		lista.add(ganso1);
		lista.add(morcego1);
		
		for (Animal animal : lista) {
			
			if(animal.getEmitirSom() instanceof Grasno){
				System.out.println(animal.getNome());
				
			}
			
		}*/
		
		ControlaCotacao controlaCotacao = new ControlaCotacao();
		
		
		Pato pato1 = new Pato();
		Morcego morcego1 = new Morcego();
		
		controlaCotacao.adicionarObserver(pato1);
		controlaCotacao.adicionarObserver(morcego1);
		
		controlaCotacao.setCotacao(1);
		controlaCotacao.notificar();
		
		System.out.println("Pato: " + pato1.calcularCusto());
		System.out.println("Morcego: " + morcego1.calcularCusto());
		
		controlaCotacao.setCotacao(2);
		controlaCotacao.notificar();
		
		System.out.println("Pato: " + pato1.calcularCusto());
		System.out.println("Morcego: " + morcego1.calcularCusto());
		
		
		


		
	}

}
