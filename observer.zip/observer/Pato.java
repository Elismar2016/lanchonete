package observer;

public class Pato extends Ave implements Observer{

	@Override
	public float calcularCusto() {
		// TODO Auto-generated method stub
		return getCotacao() * 5;
	}

	@Override
	public void atualizar(float cotacao) {
		// TODO Auto-generated method stub
		setCotacao(cotacao);
	}


	
}
