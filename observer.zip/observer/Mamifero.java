package observer;

public abstract class Mamifero extends Animal{

}
