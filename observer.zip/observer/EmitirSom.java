package observer;

public interface EmitirSom {

	public void emitirSom();
	
}
