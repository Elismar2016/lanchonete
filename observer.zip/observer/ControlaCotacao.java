package observer;

import java.util.ArrayList;
import java.util.List;

public class ControlaCotacao implements Subject{
	
	List<Observer> lista;
	float cotacao;
	
	public ControlaCotacao(){
		lista = new ArrayList<Observer>();
		
	}

	@Override
	public void adicionarObserver(Observer observer) {
		// TODO Auto-generated method stub
		lista.add(observer);
		
	}

	@Override
	public void removerObserver(Observer observer) {
		// TODO Auto-generated method stub
		int index = lista.indexOf(observer);
		lista.remove(index);
	}

	@Override
	public void notificar() {
		// TODO Auto-generated method stub
		for(int i=0;i<lista.size();i++){			
			Observer observer = lista.get(i);
			observer.atualizar(this.cotacao);
		}
		
	}
	
	public void setCotacao(float cotacao){
		
		this.cotacao = cotacao;
	}

	
	
}
