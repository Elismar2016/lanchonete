package observer;

public class Periquito extends Ave implements Observer{

	@Override
	public float calcularCusto() {
		// TODO Auto-generated method stub
		return getCotacao() * 1;
	}

	public void atualizar(float cotacao) {
		// TODO Auto-generated method stub
		setCotacao(cotacao);
	}
}
