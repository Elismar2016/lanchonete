package observer;

public class Voo implements Locomocao{

	@Override
	public void locomover() {
		// TODO Auto-generated method stub
		System.out.println("Voando ...");
	}

	
	
}
