package observer;

public abstract class Animal {

	private EmitirSom emitirSom;
	private Locomocao locomover;
	private float cotacao; 
	
	public Locomocao getLocomover() {
		return locomover;
	}
	public void setLocomover(Locomocao locomover) {
		this.locomover = locomover;
	}
	private String nome;
	private int id;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public EmitirSom getEmitirSom() {
		return emitirSom;
	}
	public void setEmitirSom(EmitirSom emitirSom) {
		this.emitirSom = emitirSom;
	}
	public float getCotacao() {
		return cotacao;
	}
	public void setCotacao(float cotacao) {
		this.cotacao = cotacao;
	}
	
	public abstract float calcularCusto();
}
