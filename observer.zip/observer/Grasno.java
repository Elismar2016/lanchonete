package observer;

public class Grasno implements EmitirSom{

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		System.out.println("grasnando ...");
	}

	
	
}
