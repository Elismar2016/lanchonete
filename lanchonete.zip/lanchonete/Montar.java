package lanchonete;

public interface Montar{

	public void montar();
	
}
