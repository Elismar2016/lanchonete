/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lanchonete;

/**
 *
 * @author Administrador
 */
public class MontarLanche {
      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        // observador é adicionado .
        //alface,pao,hamburger etc...
        /*
		ControlaCotacao controlaCotacao = new ControlaCotacao();
		
		
		Pato pato1 = new Pato();
		Morcego morcego1 = new Morcego();
		
		controlaCotacao.adicionarObserver(pato1);
		controlaCotacao.adicionarObserver(morcego1);
		
		controlaCotacao.setCotacao(1);
		controlaCotacao.notificar();
		
		System.out.println("Pato: " + pato1.calcularCusto());
		System.out.println("Morcego: " + morcego1.calcularCusto());
		
		controlaCotacao.setCotacao(2);
		controlaCotacao.notificar();
		
		System.out.println("Pato: " + pato1.calcularCusto());
		System.out.println("Morcego: " + morcego1.calcularCusto());
		
		
		*/
    }
    
}
