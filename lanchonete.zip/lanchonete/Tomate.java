package lanchonete;

public class Tomate extends Verdura implements Observer {

	public float calcularCusto() {
		// TODO Auto-generated method stub
		return getValor() * 4;
	}
	
	public void atualizar(float valor) {
		// TODO Auto-generated method stub
		setValor(valor);
	}

    private int getValor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setValor(float valor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
	

}
