package lanchonete;

public interface Subject {

	public void adicionarObserver(Observer observer);
	public void removerObserver(Observer observer);
	public void notificar();
	
}
