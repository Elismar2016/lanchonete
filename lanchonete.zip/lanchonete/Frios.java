package lanchonete;

public interface Frios {

	
	
}
