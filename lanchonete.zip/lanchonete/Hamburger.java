package lanchonete;

public class Hamburger implements Frios, Observer{

	public float calcularCusto() {
		// TODO Auto-generated method stub
		return getValor() * 5;
	}

	@Override
	public void atualizar(float valor) {
		// TODO Auto-generated method stub
		setValor(valor);
	}

    private void setValor(float valor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


	
}
