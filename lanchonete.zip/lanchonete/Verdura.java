package lanchonete;

public abstract class Verdura{


}
