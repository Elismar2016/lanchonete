package lanchonete;

public interface Observer {

	public void atualizar(float valor);
	
}
