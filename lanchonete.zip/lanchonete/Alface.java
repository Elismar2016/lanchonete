package lanchonete;

public class Alface extends Verdura implements Observer{

	public float calcularCusto() {
		// TODO Auto-generated method stub
		return getCotacao() * 2;
	}

	public void atualizar(float valor) {
		// TODO Auto-generated method stub
		setValor(valor);
	}

    private int getCotacao() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void setValor(float valor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
	
}
